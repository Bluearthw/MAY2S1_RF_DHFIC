#! /bin/bash

# source /users/micas/micas/design/scripts/assura_4.15.111.rc
# source /users/micas/micas/design/scripts/ic_6.1.6.080.rc
source ~micasusr/design/scripts/ads_2023.u2.rc
#source /users/micas/micas/design/scripts/ic_0_mmsim_13.11.rc
#source /users/micas/micas/design/scripts/ic_0_mmsim_15.10.
#source /users/micas/micas/design/scripts/pve_11.12.rc

#/esat/micas_sata/software/ic_6.1.5/tools/dfII/bin/virtuoso &
ads&
